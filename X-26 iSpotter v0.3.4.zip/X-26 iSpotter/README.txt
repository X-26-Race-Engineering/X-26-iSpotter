How to Install 
1. Double click install_telemetry.bat 
2. IF YOU DONT HAVE PYTHON: The file will install python and ask you to manually download if it errors,
   IF IT ERRORS:
      1. Go to https://www.python.org/downloads/release/python-3127/ and download your respective package
      2. Restart install_telemetry file
3. Wait for the file to install all necessary packages and prompt you to run the server
4. Once the second terminal is open, click on one of the two links provided that end in :5000 (ctrl + click)
5. Ensure iRacing is open and you are in a session before starting the stream, nothing will happen if you
   start it before iracing is open or in session but just to ensure connection is made between the app and
   iracing
6. Once installed, there should be a shortcut made on your desktop to re-open the run terminal where you can
   navigate to the app from